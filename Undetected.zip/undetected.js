(function () {
    let script = document.createElement("script"); 
    script.type = 'text/javascript'; 
    script.id = "scripttttttt"; 
    script.innerHTML = `
    //Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
    const newProto = navigator.__proto__;
    delete newProto.webdriver;
    navigator.__proto__ = newProto;
    document.getElementById('scripttttttt').remove();
    `; 
    document.documentElement.prepend(script);
    console.log("what");
})();